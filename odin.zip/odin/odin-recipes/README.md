# odin-recipes

This website provides a detailed guidlines on how to create various types of recipes using the knowledge of HTML to create the Recipe website. Some of the skills learnt is how to use basic html tags, Heading, image tags, hyperlink and listing tags.

